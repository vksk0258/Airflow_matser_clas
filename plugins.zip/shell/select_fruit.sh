FRUIT=$1
if [ $FRUIT == APPLE ];then
    echo "You selected Apple!"
else [ $FRUIT == GRAPE ];
    echo "Grape"
fi